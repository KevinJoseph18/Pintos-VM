#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "./process.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "lib/kernel/list.h"
#include "threads/synch.h"
#include "vm/page.h"

#define STACK_BOTTOM  0x08048000

static void syscall_handler (struct intr_frame *);
struct lock filesys_lock;


void
syscall_init (void) 
{
  /* initiate a global lock for the filesystem so we can 
  ensure mutual exclusion */
  lock_init(&filesys_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

/* helper function to get an argument off the stack in syscall handler */
void* get_arg(void **esp, int argnum) 
{
  return (void*) *(esp + (argnum + 1));
}

bool validate_stack_pointer(void *p) {
  if (p == NULL || is_kernel_vaddr(p) || 
  pagedir_get_page(thread_current()->pagedir, p) == NULL && 
  page_lookup(p, &thread_current()->spage_table) == NULL)
  {
    return false;
  } 
  else
  {
    return true;
  }
}

/* helper function to make sure a pointer points in the 
process's address space and is allocated */
/*Kevin Driving*/
bool validate_user_pointer(void *p) {
  if (p == NULL || is_kernel_vaddr(p) )
  {
    return false;
  } 
  else
  {
    return true;
  }
}


/* handles all syscalls - given an interrupt frame */
static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  /*Kevin Driving*/
  /*check that f is a valid pointer*/
  if (!f) {
    thread_exit();
  }

  /*check that esp is a good and valid pointer*/
  if (!validate_stack_pointer(f->esp)) {
    thread_exit();
  }

  thread_current()->esp = f->esp;



  switch (*(int*)f->esp) {
    /* system calls enumerated here */
    /*Kevin Driving*/
    case SYS_HALT:
    {
      /* only time pintos should fully shut down */
      shutdown_power_off();
      break;
    }
    case SYS_EXIT: 
    {
      /*Anvith Driving*/
      int status = (int) get_arg(f->esp, 0);
      /* exit status cannot be negative unless it's -1 */
      if (status < -1) 
      {
        exit(-1);
      } else 
      {
        exit(status);
      }
      
      break;
    }
    case SYS_EXEC:
    {
      /*Anvith Driving*/
      char *cmdline = (char *) get_arg(f->esp, 0);
      if (!validate_user_pointer(cmdline)) 
      {
        thread_exit();
      }
      tid_t pid = exec(cmdline);
      f->eax = pid;
      break;
    }
    case SYS_WAIT:
    {
      /*Anvith Driving*/
      tid_t pid = (int) get_arg(f->esp, 0);
      int result = wait(pid);
      f->eax = result;
      break;
    }
    /* acquire global filesys lock to ensure that all file system operations
      are atomic */ 
    case SYS_CREATE:
    {
      /*Guy Driving*/
      const char *file = (char *) get_arg(f->esp, 0);
      unsigned init_size = (unsigned) get_arg(f->esp, 1);
      if (!validate_user_pointer(file))
      {
        thread_exit();
      }
      lock_acquire(&filesys_lock);
      f->eax = filesys_create(file, init_size);
      lock_release(&filesys_lock);
      break;
    }

    case SYS_REMOVE:
    {
      /*Guy Driving*/
      const char *file = (char *) get_arg(f->esp, 0);
      if (!validate_user_pointer(file))
      {
        thread_exit();
      }
      lock_acquire(&filesys_lock);
      f->eax = filesys_remove(file);
      lock_release(&filesys_lock);
      break;
    }

    case SYS_OPEN:
    {
      /*Kevin Driving*/
      const char *file = (char * ) get_arg(f->esp, 0);
      if (!validate_user_pointer(file))
      {
        thread_exit();
      }
      lock_acquire(&filesys_lock);
      f->eax = open(file);
      lock_release(&filesys_lock);
      break;
    }


    case SYS_FILESIZE:
    {
      /*Kevin Driving*/
      int fd = (int) get_arg(f->esp, 0);
      lock_acquire(&filesys_lock);  
      f->eax = filesize(fd);
      lock_release(&filesys_lock);
      break;
    }
    case SYS_READ:
    {
      /*Kevin Driving*/
      int fd = (int) get_arg(f->esp, 0);
      void *buffer = get_arg(f->esp, 1);
      unsigned size = (unsigned) get_arg(f->esp, 2);
      /* preload buffer and pin */
      int i = 0;
      while (i < size + PGSIZE - size%PGSIZE)
      {
        if (!validate_user_pointer(buffer + i))
        {
          thread_exit();
        }
        if (pagedir_get_page(thread_current()->pagedir, buffer + i) == NULL)
        {
          
          if (!load_in_addr(buffer + i, false, thread_current()->esp))
          {
            thread_exit();
          }
        }
        struct sup_page_entry* entry = page_lookup(buffer + i, 
        &thread_current()->spage_table);
        lock_acquire(&entry->mutex);
        entry->pin = true;
        lock_release(&entry->mutex);
        i += PGSIZE;
      }
      

      lock_acquire(&filesys_lock);
      f->eax = read(fd, buffer, size);
      lock_release(&filesys_lock);

      /* unpin buffer */
      i = 0;
      while (i < size + PGSIZE - size%PGSIZE)
      {
        struct sup_page_entry* entry = page_lookup(buffer + i, &thread_current()->spage_table);
        lock_acquire(&entry->mutex);
        entry->pin = false;
        lock_release(&entry->mutex);
        i += PGSIZE;
      }
      break;
    }
    case SYS_WRITE:
    {
      /*Kevin Driving*/
      int fd = (int) get_arg(f->esp, 0);
      void *buffer = get_arg(f->esp, 1);
      unsigned size = (unsigned) get_arg(f->esp, 2);
      if (!validate_user_pointer(buffer)) 
      {
        /* TODO, handle error */
        thread_exit();
      }
      /* Guy Driving */
      /* preload buffer and pin */
      int i = 0;
      while (i < size + PGSIZE - size%PGSIZE)
      {
        if (!validate_user_pointer(buffer + i))
        {
          thread_exit();
        }
        if (pagedir_get_page(thread_current()->pagedir, buffer + i) == NULL)
        {
          
          if (!load_in_addr(buffer + i, false, thread_current()->esp))
          {
            thread_exit();
          }
        }
        struct sup_page_entry* entry = page_lookup(buffer + i, 
        &thread_current()->spage_table);
        lock_acquire(&entry->mutex);
        entry->pin = true;
        lock_release(&entry->mutex);
        i += PGSIZE;
      }

      lock_acquire(&filesys_lock);
      f->eax = write(fd, buffer, size);
      lock_release(&filesys_lock); 

       /* unpin buffer */
      i = 0;
      while (i < size + PGSIZE - size%PGSIZE)
      {
        struct sup_page_entry* entry = page_lookup(buffer + i, 
        &thread_current()->spage_table);
        lock_acquire(&entry->mutex);
        entry->pin = false;
        lock_release(&entry->mutex);
        i += PGSIZE;
      }
      
      break;
    }
    case SYS_SEEK:
    {
      /*Guy Driving*/
      int fd = (int) get_arg(f->esp, 0);
      unsigned position = (unsigned) get_arg(f->esp, 1);
      lock_acquire(&filesys_lock);
      seek(fd, position);
      lock_release(&filesys_lock);
      break;
    }
    case SYS_TELL:
    {
      /*Guy Driving*/
      int fd = (int) get_arg(f->esp, 0);
      lock_acquire(&filesys_lock);
      tell(fd);
      lock_release(&filesys_lock);
      break;
    }
    case SYS_CLOSE:
    {
      /*Kevin Driving*/
      int fd = (int) get_arg(f->esp, 0);
      lock_acquire(&filesys_lock);
      close(fd);
      lock_release(&filesys_lock);
      break;
    }
  }
}

/* iterates through current thread's open files and returns the open_file struct 
  with the corresponding file descriptor 
  returns NULL if corresponding file desc doesn't exist
*/
/*Anvith Driving*/
struct open_file *get_file_from_fd (int fd)
{
  struct list_elem *e;
  struct open_file *file;
  struct thread *cur = thread_current();
  for (e = list_begin(&cur->fd_list); e != list_end(&cur->fd_list); 
  e = list_next(e))
  {
    file = list_entry(e, struct open_file, elem);
    if (file->fd == fd)
    {
      return file;
    }
  }
  return NULL;
}

/*adds the new file to the file descriptor table of the current thread 
  returns the newly assigned file descriptor
  these are only unique within the files for a single process
*/
/*Guy Driving*/
int add_to_fd_list (struct open_file *newfile)
{
  if (list_empty(&thread_current()->fd_list))
  {
    newfile->fd = 2;
  }
  else
  {
    struct list_elem *e = list_back(&thread_current()->fd_list);
    int new_fd = list_entry(e, struct open_file, elem)->fd + 1;
    newfile->fd = new_fd;
  }
  list_push_back(&thread_current()->fd_list, &newfile->elem);
  return newfile->fd;
}

/*Kevin Driving*/
/* closes a given open file if the fd exists within the current
  thread's file descriptor table
  deallocates memory for the open_file struct */
void close (int fd)
{
  struct open_file *opf = get_file_from_fd(fd);
  if (opf == NULL)
  {
    return;
  }
  file_close(opf->fileptr);
  list_remove(&opf->elem);
  palloc_free_page(opf);
}
/*Guy Driving*/
/*calls file_seek operation given a file descriptor*/
void seek (int fd, unsigned position)
{
  struct open_file *opf = get_file_from_fd(fd);
  if (opf != NULL)
    file_seek(opf->fileptr, position);
}
/*Guy Driving*/
/*calls file_tell operation given a file descriptor*/
int tell (int fd)
{
  struct open_file *opf = get_file_from_fd(fd);
  if (opf != NULL)
    file_tell(opf->fileptr);
}

/*Kevin Driving*/
/*helper function to close all current thread's open files
  and deallocate the given memory*/
void close_open_files()
{
  struct list_elem *e;
  struct open_file *opf;
  struct thread *cur = thread_current();
  while (!list_empty(&cur->fd_list))
  {
    e = list_pop_front(&cur->fd_list);
    opf = list_entry(e, struct open_file, elem);
    file_close (opf->fileptr);
    palloc_free_page(opf);
  }
}
/*Anvith Driving*/
/*returns the size of an open file given file descriptor*/
int filesize (int fd)
{
  struct open_file *opf = get_file_from_fd(fd);
  if (opf == NULL)
  {
    return -1;
  }
  return file_length (opf->fileptr);
}
/*Kevin Driving*/
/*opens a given file and adds it to the current thread's file
  descriptor table*/
int open (const char *file)
{
  struct open_file *newfile = palloc_get_page(0);
  struct file *opened = filesys_open(file);
  if (opened == NULL || newfile == NULL) 
  {
    return -1;
  } 
  newfile->fileptr = opened;
  int fd = add_to_fd_list(newfile);
  return fd;
}
/*Anvith Driving*/
/* makes current thread waits for child with argument pid */
int wait (tid_t pid) 
{
  return process_wait(pid);
}
/*Anvith Driving*/
/* creates a new thread and has it execute the program specified in
 commandline with args from cmdline */
tid_t exec(const char *cmd_line) 
{
  tid_t tid = process_execute(cmd_line);
  if (tid == TID_ERROR) 
  {
    return -1;
  } else { 
    struct thread *c = get_child_from_tid(tid, thread_current());
    if (c == NULL) 
    {
      /* this should not happen; if process_execute succeeded 
      tid did not return error),  the child should be in our children list. 
      TODO handle error*/
      printf("\nVERY BAD\n");
    }
    
    return c->pid;
  }
}
/*Kevin Driving*/
/* exits current thread, cleaning up its resources */
void exit(int status) 
{

  struct thread *cur = thread_current();
  cur->exit_status = status;

  thread_exit();
}

/*Kevin Driving*/
/* reads from either a file or STDIN using built in Pintos functions*/
int read (int fd, void *buffer, unsigned size)
{
  if (fd == 0)
  {
    input_getc();
    return size;
  }
  else
  {
    struct open_file *opf = get_file_from_fd(fd);
    if (opf == NULL)
    {
      return -1;
    }
    return file_read(opf->fileptr, buffer, size);
  }

}
/*Kevin Driving*/
/*writes to either STDOUT or a file using built in Pintos functions*/
int write (int fd, const void *buffer, unsigned size) 
{
  if (fd == 1) 
  {
    /*write to console*/
    putbuf(buffer, size);
    return size;
  } 
  else 
  {
    struct open_file *opf = get_file_from_fd(fd);
    if (opf == NULL)
    {
      return -1;
    }
    return file_write(opf->fileptr, buffer, size);
  }
}
