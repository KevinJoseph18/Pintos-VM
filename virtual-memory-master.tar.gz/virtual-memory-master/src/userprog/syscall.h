#include "lib/kernel/list.h"

#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

struct lock filesys_lock;

/* file stuct to store files in file descriptor table */
/*Kevin Driving*/
struct open_file
{
  int fd;
  struct file *fileptr;
  struct list_elem elem;
};

void syscall_init (void);


#endif /* userprog/syscall.h */
