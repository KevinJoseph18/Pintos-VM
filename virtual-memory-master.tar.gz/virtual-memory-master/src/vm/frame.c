#include <stdint.h>
#include "vm/frame.h"
#include "threads/palloc.h"
#include "threads/synch.h"
#include "threads/vaddr.h"
#include "threads/loader.h"
#include "vm/swap.h"
#include "vm/page.h"
#include "userprog/pagedir.h"
#include "threads/thread.h"

#define OFFSET_BITS 12
#define FRAME_NUM_BITS 20

int clock_hand;
struct lock clock_lock;

uint32_t user_frame_offset;
size_t num_frames;

/* Anvith Driving */
/* function to translate address from kernel vaddr to 
   physical address and get corresponding frame table index */
size_t frame_num_from_kernel_addr(void* kernel_addr) 
{
    uintptr_t phys_addr = vtop(kernel_addr);
    return (((unsigned) phys_addr) >> OFFSET_BITS) - user_frame_offset;
}
/* Anvith Driving */

/* initializes frame table and loads up all user pages of memory so that
   programs can only receive memory from our allocator 
   (called by init.c) */ 
void frame_table_init(uint32_t user_pages) 
{
    clock_hand = 0;
    lock_init(&clock_lock);
    user_frame_offset = init_ram_pages - user_pages + 1;
    frame_table = malloc(user_pages * sizeof(struct frame_table_entry));
    if (frame_table == NULL)
        thread_exit();
    /* pre-emptively allocate all frame-entries */
    int i;
    for (i = 0; i < user_pages; i++) 
    {
        void* kernel_addr = palloc_get_page(PAL_USER);
        if (kernel_addr == NULL) 
        {
            /* we have less user pages available than we're supposed to; 
            that's ok, update number of frames to be correct.*/
            num_frames = i;
            break;
        }
        /* get frame number from kernel_addr */
        size_t frame_num = frame_num_from_kernel_addr(kernel_addr);
        struct frame_table_entry* entry = (frame_table + frame_num);
       
        entry->is_free = true;
        lock_init(&entry->mutex);
        entry->kernel_addr = kernel_addr;
        entry->owner = NULL;
        entry->sup_page_entry = NULL;
    }
}

/* Guy Driving */
/* gives a frame to the page in the parameter
   returns the vaddr of this frame */
void* allocate_frame(struct thread* owner, bool zero, 
struct sup_page_entry* sup_page_entry)
{
    /* iterate over frame table until we hit a free frame */
    void* return_address = NULL;
    int i;
    for (i = 0; i < num_frames; i++) 
    {
        struct frame_table_entry* entry = (frame_table + i);
        lock_acquire(&entry->mutex);
        if (entry->is_free)
        {
            /* found it */
            entry->is_free = false;
            entry->owner = owner;
            entry->sup_page_entry = sup_page_entry;
            return_address = entry->kernel_addr;
        }
        lock_release(&entry->mutex);
        if (return_address != NULL)
        {
            break;
        }
    }

    if (return_address == NULL)
    {
        struct frame_table_entry* entry = find_eviction_frame();
        lock_acquire(&entry->mutex);
        evict_frame(entry);
        entry->is_free = false;
        entry->owner = owner;
        entry->sup_page_entry = sup_page_entry;
        return_address = entry->kernel_addr;
        lock_release(&entry->mutex);
    }
    
    if (return_address != NULL && zero) 
    {
        memset (return_address, 0, PGSIZE);
    }
    return return_address;
}

/* Guy Driving */
/* Clock eviction algorithm to decide frame to evict when all frames 
are full. Uses a global clock hand variable*/
struct frame_table_entry* find_eviction_frame()
{
    lock_acquire(&clock_lock);
    /* if we're here, all frames are in use */
    while (true)
    {
        struct frame_table_entry* frame = (frame_table + clock_hand);
        lock_acquire(&frame->mutex);
        struct sup_page_entry* entry = frame->sup_page_entry;
        lock_acquire(&entry->mutex);
        if (entry->pin)
        {
            lock_release(&entry->mutex);
            lock_release(&frame->mutex);
            clock_hand++;
            clock_hand %= num_frames;
            continue;
        }
        bool accessed = 
        pagedir_is_accessed(frame->owner->pagedir, entry->vaddr);
        if (!accessed)
        {
            lock_release(&entry->mutex);
            lock_release(&frame->mutex);
            clock_hand++;
            clock_hand %= num_frames;
            lock_release(&clock_lock);
            return frame;
        } else
        {
            pagedir_set_accessed(frame->owner->pagedir, entry->vaddr, false);
            lock_release(&entry->mutex);
            lock_release(&frame->mutex);
            clock_hand++;
            clock_hand %= num_frames;
            continue;
        }
    }
}
/* Kevin Driving */
/* called to free frame in physical memory given the kernel address */
void free_frame(void* kernel_addr) 
{
    size_t frame_num = frame_num_from_kernel_addr(kernel_addr);
    struct frame_table_entry* entry = (frame_table + frame_num);
    lock_acquire(&entry->mutex);
    if (entry->is_free) 
    {
        /* freeing already free frame. Not sure if should punish caller
        or not. */
        lock_release(&entry->mutex);
        return;
    }
    free_frame_worker(entry);
    lock_release(&entry->mutex);
}

/* Kevin Driving */
/* called to free frame in memory given the actual frame entry*/
void free_frame_worker(struct frame_table_entry* entry)
{
    /* assert some preconditions */
    ASSERT(lock_held_by_current_thread(&entry->mutex));
    ASSERT(!entry->is_free);
    ASSERT(entry->owner != NULL);
    ASSERT(entry->sup_page_entry != NULL);

    entry->is_free = true;
    entry->owner = NULL;
    entry->sup_page_entry = NULL;
}
/* Guy Driving */
/* Called by allocate_frame after find_eviction_frame
writes the data in the evicted frame to swap partition and
stores the necessary data in the corresponding sup_page_entry */
void evict_frame(struct frame_table_entry* entry)
{
    /* assert some preconditions */
    ASSERT(lock_held_by_current_thread(&entry->mutex));
    ASSERT(!entry->is_free);
    ASSERT(entry->owner != NULL);
    ASSERT(entry->sup_page_entry != NULL);

    struct sup_page_entry* sup_page_entry = entry->sup_page_entry;
    lock_acquire(&sup_page_entry->mutex);
    lock_acquire(&swap_lock);
    
    /* update page_dir */
    pagedir_clear_page(entry->owner->pagedir, sup_page_entry->vaddr);

    /* write to swap */
    size_t slot = write_page_to_swap(entry);

    /* update sup_page_entry */
    sup_page_entry->in_memory = false;
    sup_page_entry->in_swap = true;
    sup_page_entry->swap_slot = slot;

    /* update frame */
    free_frame_worker(entry);

    lock_release(&swap_lock);
    lock_release(&sup_page_entry->mutex);

    /* it is up to caller to release entry's lock */
}


