#ifndef VM_PAGE_H
#define VM_PAGE_H

#include <stdint.h>
#include "vm/frame.h"
#include "threads/palloc.h"
#include "threads/synch.h"
#include "lib/kernel/hash.h"
#include "filesys/off_t.h"

/* Guy Driving */
struct sup_page_entry
{
	struct lock mutex; 
	/* the following 3 fields never change after initialization, 
		so are safe to read without mutex */
	size_t page_num; /* the page number off this page, 
		used to index sup page table */
	void *vaddr; /* stores process virtual address of this page */
	struct hash_elem elem; /* used to store entry in a hash table */

	/*this means it's safe to navigate hash table without acquiring
		lock, since that relies only on these fields */

	bool zero; /* is this page all zero */
	bool in_memory; /* used to handle page faults (location of data) */
	struct file* file; /* if it is on disk, what file */
	off_t file_offset; /* if it is on disk, where on file */
	size_t page_read_bytes; /* how many bytes to read from file */
	bool in_swap; /* used to handle page faults (location of data) */
	size_t swap_slot; /* if in swap, which slot */
	bool writable; /* whether this page is writable or read-only */
	bool pin; /* if true, this page should not be evicted */
};

hash_action_func hash_destroy_entry;

hash_hash_func hash_page;

hash_less_func hash_less_page;

struct sup_page_entry* initialize_vpage (void* vaddr, bool zero, 
struct file* file, off_t file_offset, bool write, struct hash* spage_table,
	size_t page_read_bytes);

#endif /* VM_PAGE_H */
