#ifndef VM_SWAP_H
#define VM_SWAP_H

#include <stdint.h>
#include "vm/frame.h"
#include "threads/palloc.h"
#include "threads/synch.h"
#include "devices/block.h"
/* Anvith Driving */
struct bitmap* swap_table;
struct lock swap_lock;
struct block* swap_block;
void swap_init(size_t block_sectors, struct block* swap_block);

size_t write_page_to_swap(struct frame_table_entry* entry);

void load_page_from_swap(void* kernel_addr, struct sup_page_entry* entry);

void swap_free(size_t slot);


#endif /* VM_SWAP_H */
