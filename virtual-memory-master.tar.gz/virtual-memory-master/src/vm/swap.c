#include <stdint.h>
#include "vm/frame.h"
#include "threads/palloc.h"
#include "threads/synch.h"
#include "threads/vaddr.h"
#include "threads/loader.h"
#include "lib/kernel/bitmap.h"
#include "devices/block.h"
#include "vm/swap.h"
#include "vm/page.h"
#include "userprog/syscall.h"

#define BLOCK_SECTOR_SIZE 512
#define SECTORS_PER_PAGE PGSIZE/BLOCK_SECTOR_SIZE
/* Kevin Driving */
/* initializes swap table and necessary bitmap. Actual initialization
of the block is handled in in it.c */
void swap_init(size_t block_sectors, struct block* block)
{
    lock_init(&swap_lock);
    swap_block = block; 
    size_t bit_cnt = (block_sectors * BLOCK_SECTOR_SIZE) / PGSIZE; 
    swap_table = bitmap_create(bit_cnt);
}
/* Kevin Driving */
/* writes data in the frame table entry into the swap partition */
size_t write_page_to_swap(struct frame_table_entry* entry)
{
    ASSERT(lock_held_by_current_thread(&entry->mutex));
    ASSERT(lock_held_by_current_thread(&swap_lock));
    ASSERT(!entry->is_free);
    ASSERT(entry->kernel_addr);
    size_t slot = bitmap_scan_and_flip(swap_table, 0, 1, false);
    if (slot == BITMAP_ERROR)
    {
        /* no room in swap */
        PANIC("No swap space left");
    }
    bool in_file_sys_call = lock_held_by_current_thread(&filesys_lock);
    if (!in_file_sys_call)
    {
        lock_acquire(&filesys_lock);
    }
    int i;
    for (i = 0; i < SECTORS_PER_PAGE; i++) 
    {
        block_write(swap_block, slot * SECTORS_PER_PAGE + i, 
        entry->kernel_addr + (i * BLOCK_SECTOR_SIZE));
    }
    if (!in_file_sys_call)
    {
        lock_release(&filesys_lock);
    }
    return slot;
}
/* Guy Driving */
/* given a sup_page_entry, reads the data from swap and loads it into physical
frame of memory */
void load_page_from_swap(void* kernel_addr, struct sup_page_entry* entry)
{
    ASSERT(lock_held_by_current_thread(&entry->mutex));
    ASSERT(entry->in_swap);
    lock_acquire(&swap_lock);
    size_t slot = entry->swap_slot;
    ASSERT(bitmap_test(swap_table, slot));
    bool in_file_sys_call = lock_held_by_current_thread(&filesys_lock);
    if (!in_file_sys_call)
    {
        lock_acquire(&filesys_lock);
    }
    int i;
    for (i = 0; i < SECTORS_PER_PAGE; i++) 
    {
        block_read(swap_block, slot * SECTORS_PER_PAGE + i, 
        kernel_addr + (i * BLOCK_SECTOR_SIZE));
    }
    if (!in_file_sys_call)
    {
        lock_release(&filesys_lock);
    }
    bitmap_flip(swap_table, slot);
    lock_release(&swap_lock);
}
/* Guy Driving */ 
/* frees the swap slot by flipping the corresponding bitmap entry*/
void swap_free(size_t slot)
{
    lock_acquire(&swap_lock);
    ASSERT(bitmap_test(swap_table, slot));
    bitmap_flip(swap_table, slot);
    lock_release(&swap_lock);
}

