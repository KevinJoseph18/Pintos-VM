#include <stdint.h>
#include "lib/kernel/hash.h"
#include "vm/page.h"
#include "filesys/off_t.h"
#include "threads/thread.h"
#include "userprog/pagedir.h"
#include "vm/swap.h"

#define OFFSET_BITS 12

/* Kevin Driving */
/* hash_action_func used to free resources when deleting entries from
sup page table*/
void hash_destroy_entry (struct hash_elem *e, void *aux)
{
    struct sup_page_entry* entry = hash_entry(e, struct sup_page_entry, elem);
    lock_acquire(&entry->mutex);
    if (!entry->in_memory)
    {
        /* no need to free any frames. not in memory. */
        if (entry->in_swap)
        {
            /* TODO free swap somehow? */
            swap_free(entry->swap_slot);
            lock_release(&entry->mutex);
            free(entry);
        } else 
        {
            lock_release(&entry->mutex);
            /* no need to worry about another thread accessing this
                before we free because it is not in memory, and only time
                other threads access this is for eviction */
            free(entry);
        }
    } else 
    {
        /* reclaim frame */
        entry->in_memory = false;
        void* kaddr = pagedir_get_page(thread_current()->pagedir, entry->vaddr);
        free_frame(kaddr);
        
        lock_release(&entry->mutex);
        /* no need to worry about another thread accessing this
            before we free because it is not in memory, and only time
            other threads access this is for eviction */
        free(entry);
    }

}
/* Anvith Driving */
/* hash_hash_func to hash page table entries based on the page number */
unsigned hash_page (const struct hash_elem *e, void *aux) 
{
    struct sup_page_entry* entry = hash_entry(e, struct sup_page_entry, elem);
    return hash_int(entry->page_num);
}
/* Anvith Driving */
/* hash_less_func used to compare hash table elements by the page number */
bool hash_less_page (const struct hash_elem *a, 
    const struct hash_elem *b, void *aux)
{
    struct sup_page_entry* entry_a = hash_entry(a, 
        struct sup_page_entry, elem); 
    struct sup_page_entry* entry_b = hash_entry(b, 
        struct sup_page_entry, elem);
    return (entry_a->page_num < entry_b->page_num);
}

/* Guy Driving */
/* called in load segment to set up the sup page table entry for
any address that is needed. Actual loading of the data is handled 
later when it page faults */
struct sup_page_entry* initialize_vpage (void* vaddr, bool zero, 
struct file* file, off_t file_offset, bool write, struct hash* spage_table,
    size_t page_read_bytes)
{
    struct sup_page_entry* entry = malloc(sizeof(struct sup_page_entry));
    lock_init(&entry->mutex);
    entry->page_num = ((size_t) vaddr) >> OFFSET_BITS;
    entry->vaddr = entry->page_num << OFFSET_BITS;
    entry->zero = zero;
    entry->in_memory = false;
    entry->file = file;
    entry->file_offset = file_offset;
    entry->in_swap = false;
    entry->swap_slot = 0;
    entry->writable = write;
    entry->page_read_bytes = page_read_bytes;
    entry->pin = false;

    hash_insert(spage_table, &entry->elem);

    return entry;
}


/* Returns the page containing the given virtual address,
   or a null pointer if no such page exists. 
   
    Based on example from Pintos documentation
    Guy Driving
   */
struct sup_page_entry* page_lookup (const void *vaddr,
    struct hash* spage_table)
{
    struct sup_page_entry entry;
    struct hash_elem *e;

    entry.page_num = ((size_t) vaddr) >> OFFSET_BITS;
    e = hash_find (spage_table, &entry.elem);
    return e != NULL ? hash_entry (e, struct sup_page_entry, elem) : NULL;
}

/* Reclaims all frames and frees sup page table */
/* Guy Driving */
void free_pages(struct thread* t)
{
    hash_destroy(&t->spage_table, hash_destroy_entry);
}