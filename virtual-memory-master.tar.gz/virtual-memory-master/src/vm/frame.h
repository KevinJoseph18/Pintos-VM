#ifndef VM_FRAME_H
#define VM_FRAME_H

#include <stdint.h>
#include "vm/frame.h"
#include "threads/palloc.h"
#include "threads/synch.h"

/* Kevin Driving */

struct frame_table_entry 
{
    struct lock mutex;
    bool is_free;
    void* kernel_addr;
    struct thread* owner;
    struct sup_page_entry* sup_page_entry;
    // Maybe store information for memory mapped files here too?
};

size_t frame_num_from_kernel_addr(void* kernel_addr);

void frame_table_init(uint32_t frames);

void* allocate_frame(struct thread* owner, bool zero, 
struct sup_page_entry * sup_page_entry);

struct frame_table_entry* find_eviction_frame();

void free_frame(void* kernel_addr);

struct frame_table_entry* frame_table;

#endif /* VM_FRAME_H */
